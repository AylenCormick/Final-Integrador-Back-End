package com.example.Final.Ingregrador.Back.End;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalIngregradorBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
